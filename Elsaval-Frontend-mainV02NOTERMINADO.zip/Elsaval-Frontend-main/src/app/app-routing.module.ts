import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { SignupComponent } from './pages/signup/signup.component';
import { LoginComponent } from './pages/login/login.component';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './pages/user/user-dashboard/user-dashboard.component';
import { AdminGuard } from './services/admin.guard';
import { NormalGuard } from './services/normal.guard';
import { ProfileComponent } from './pages/profile/profile.component';
import { WelcomeComponent } from './pages/admin/welcome/welcome.component';
import { ViewAlmacenComponent } from './pages/admin/view-almacen/view-almacen.component';
import { AddAlmacenComponent } from './pages/admin/add-almacen/add-almacen.component';
import { ViewElementosComponent } from './pages/admin/view-elementos/view-elementos.component';
import { ViewUsuariosComponent } from './pages/admin/view-usuarios/view-usuarios.component';
import { AddElementoComponent } from './pages/admin/add-elemento/add-elemento.component';
import { ActualizarElementoComponent } from './pages/admin/actualizar-elemento/actualizar-elemento.component';

import { ActualizarUsuariosComponent } from './pages/admin/actualizar-usuarios/actualizar-usuarios.component';
import { ViewEspejosComponent } from './pages/admin/view-espejos/view-espejos.component';
import { AddEspejosComponent } from './pages/admin/add-espejos/add-espejos.component';
import { ViewEmpleadoComponent } from './pages/admin/view-empleado/view-empleado.component';
import { AddEmpleadoComponent } from './pages/admin/add-empleado/add-empleado.component';
import { ActializarEmpleadoComponent } from './pages/admin/actializar-empleado/actializar-empleado.component';
import { DetalleEmpleadoComponent } from './pages/admin/detalle-empleado/detalle-empleado.component';
import { ViewSocioComponent } from './pages/admin/view-socio/view-socio.component';
import { AddSocioComponent } from './pages/admin/add-socio/add-socio.component';
import { ActualizarSocioComponent } from './pages/admin/actualizar-socio/actualizar-socio.component';
import { DetalleSocioComponent } from './pages/admin/detalle-socio/detalle-socio.component';
import { AddCasaComponent } from './pages/admin/add-casa/add-casa.component';
import { ViewCasaComponent } from './pages/admin/view-casa/view-casa.component';
import { ActualizarCasaComponent } from './pages/admin/actualizar-casa/actualizar-casa.component';
import { AddLanchasComponent } from './pages/admin/add-lanchas/add-lanchas.component';
import { ViewLanchasComponent } from './pages/admin/view-lanchas/view-lanchas.component';
import { ActualizarLanchasComponent } from './pages/admin/actualizar-lanchas/actualizar-lanchas.component';
import { DetalleLanchaComponent } from './pages/admin/detalle-lancha/detalle-lancha.component';
import { UserWelcomeComponent } from './pages/user/user-welcome/user-welcome.component';
import { ProveedoresComponent } from './pages/user/proveedores/proveedores.component';
import { InvitadosComponent } from './pages/user/invitados/invitados.component';
import { ViewSolicitudLanchaComponent } from './pages/user/view-solicitudlancha/view-solicitudlancha.component';
import { AddVehiculoComponent } from './pages/admin/add-vehiculo/add-vehiculo.component';
import { ViewVehiculosComponent } from './pages/admin/view-vehiculos/view-vehiculos.component';
import { AddIngresosocioComponent } from './pages/admin/add-ingresosocio/add-ingresosocio.component';
import { ViewIngresosocioComponent } from './pages/admin/view-ingresosocio/view-ingresosocio.component';
import {AddInvitadosComponent} from './pages/user/add-invitados/add-invitados.component';
import { ActualizarInvitadosComponent } from './pages/user/actualizar-invitados/actualizar-invitados.component';
import { AddProveedoresComponent } from './pages/user/add-proveedores/add-proveedores.component';
import { ImagenComponent } from './pages/admin/imagen/imagen.component';
import { ViewProductoComponent } from './pages/admin/view-producto/view-producto.component';
import { AddProductoComponent } from './pages/admin/add-producto/add-producto.component';
import { MinusProductoComponent } from './pages/admin/minus-producto/minus-producto.component';
import { PlusProductoComponent } from './pages/admin/plus-producto/plus-producto.component';
import { ActualizarVehiculosComponent } from './pages/admin/actualizar-vehiculos/actualizar-vehiculos.component';
import { ViewInvitadosComponent } from './pages/admin/view-invitados/view-invitados.component';
import { DetalleInvitadoComponent } from './pages/admin/detalle-invitado/detalle-invitado.component';
import { ViewProveedoresComponent } from './pages/admin/view-proveedores/view-proveedores.component';
import { ActualizarProveedorComponent } from './pages/admin/actualizar-proveedor/actualizar-proveedor.component';
import { DetalleVehiculoComponent } from './pages/admin/detalle-vehiculo/detalle-vehiculo.component';
import { ViewEquipoComponent } from './pages/admin/view-equipo/view-equipo.component';
import { AddEquipoComponent } from './pages/admin/add-equipo/add-equipo.component';
import { PlusEquipoComponent } from './pages/admin/plus-equipo/plus-equipo.component';
import { MinusEquipoComponent } from './pages/admin/minus-equipo/minus-equipo.component';



const routes: Routes = [
  {
    path: '',
    component: HomeComponent,
    pathMatch: 'full'
  },
  {
    path: 'signup',
    component: SignupComponent,
    pathMatch: 'full'
  },
  {
    path: 'login',
    component: LoginComponent,
    pathMatch: 'full'
  },
  {//admin/profile
    path: 'admin',
    component: DashboardComponent,

    canActivate: [AdminGuard],
    children: [
      {
        path: 'profile',
        component: ProfileComponent
      },
      {
        path: '',
        component: WelcomeComponent
      },
      {
        path: 'almacenes',
        component: ViewAlmacenComponent
      },
      {
        path: 'addalmacen',
        component: AddAlmacenComponent
      },
      {
        path: 'usuarios',
        component: ViewUsuariosComponent
      },
      {
        path: 'usuarios/:id',
        component: ActualizarUsuariosComponent
      },
      {
        path: 'elementos',
        component: ViewElementosComponent
      },
      {
        path: 'addelementos',
        component: AddElementoComponent
      },
      {
        path: 'elemento/:elementoId',
        component: ActualizarElementoComponent
      },
      {
        path: 'espejos',
        component: ViewEspejosComponent
      },
      {
        path: 'addespejos',
        component: AddEspejosComponent
      },
      {
        path: 'empleados',
        component: ViewEmpleadoComponent
      },
      {
        path: 'addempleados',
        component:AddEmpleadoComponent
      },
      {
        path: 'empleado/:empleadoId',
        component:ActializarEmpleadoComponent
      },
      {
        path: 'empleadodet/:empleadoId',
        component:DetalleEmpleadoComponent
      },
      {
        path: 'socios',
        component:ViewSocioComponent
      },
      {
        path: 'addsocios',
        component:AddSocioComponent
      },
      {
        path: 'socio/:socioId',
        component:ActualizarSocioComponent
      },
      {
        path: 'sociodet/:socioId',
        component:DetalleSocioComponent
      },
      {
        path: 'casas',
        component:ViewCasaComponent
      },
      {
        path: 'addcasas',
        component:AddCasaComponent
      },
      {
        path: 'casa/:casaId',
        component:ActualizarCasaComponent
      },
      {
        path: 'addlanchas',
        component:AddLanchasComponent
      },
      {
        path: 'lanchas',
        component:ViewLanchasComponent
      },
      {
        path: 'lancha/:lanchaId',
        component:ActualizarLanchasComponent
      },
      {
        path: 'lanchadeta/:lanchaId',
        component:DetalleLanchaComponent
      },
      {
        path: 'addvehiculos',
        component:AddVehiculoComponent
      },
      {
        path: 'vehiculos',
        component:ViewVehiculosComponent
      },
      {
        path: 'vehiculo/:vehiculoId',
        component: ActualizarVehiculosComponent
      },
      {
        path: 'vehiculodet/:vehiculoId',
        component: DetalleVehiculoComponent
      },
      {
        path: 'addingresosocio',
        component:AddIngresosocioComponent
      },
      {
        path: 'ingresosocios',
        component:ViewIngresosocioComponent
      },
      {
        path: 'imagen',
        component:ImagenComponent
      },
      {
        path: 'productos',
        component: ViewProductoComponent,
      },
      {
        path: 'addproducto',
        component:AddProductoComponent
      },
      {
        path: 'plusproducto/:elemento_id',
        component:PlusProductoComponent
      },
      {
        path: 'minusproducto/:elemento_id',
        component:MinusProductoComponent
      },
      {
        path: 'invitados',
        component:ViewInvitadosComponent
      },
      {
        path: 'invitadodet/:invitadoId',
        component:DetalleInvitadoComponent
      },
      {
        path: 'proveedores',
        component:ViewProveedoresComponent
      },
      {
        path: 'actualizar-proveedor/:proveedorId',
        component: ActualizarProveedorComponent
      },
      {
        path: 'equipos',
        component: ViewEquipoComponent
      },
      {
        path: 'addequipo',
        component: AddEquipoComponent
      },
      {
        path: 'plusequipo/:equipo_id',
        component: PlusEquipoComponent
      },
      {
        path: 'minusequipo/:equipo_id',
        component: MinusEquipoComponent
      },
    ]
  },
  {//user/profile
    path: 'user',
    component: UserDashboardComponent,
    canActivate: [NormalGuard],
    children: [
      {
        path: 'solicitudlancha',
        component:ViewSolicitudLanchaComponent
      },
      {
        path: '',
        component: UserWelcomeComponent
      },
      {
        path: 'proveedores',
        component:ProveedoresComponent
      },
      {
        path: 'invitados',
        component:InvitadosComponent
      },
      {
        path: 'addinvitados',
        component:AddInvitadosComponent
      },
      {
        path: 'invitados/:invitadoId',
        component: ActualizarInvitadosComponent
      },
      {
        path: 'addproveedores',
        component:AddProveedoresComponent
      },
    ]
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
