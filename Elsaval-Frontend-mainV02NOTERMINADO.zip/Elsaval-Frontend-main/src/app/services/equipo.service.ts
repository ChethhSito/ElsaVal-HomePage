import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class EquipoService {

  constructor(private http:HttpClient) { }

  public listarEquipos(){
    return this.http.get(`${baserUrl}/equipos/`);
  }

  public agregarEquipo(equipo:any){
    return this.http.post(`${baserUrl}/equipos/`, equipo);
  }

  public eliminarEquipo(equipoId:any){
    return this.http.delete(`${baserUrl}/equipos/${equipoId}`);
  }
  public obtenerEquipo(equipoId:any){
    return this.http.get(`${baserUrl}/equipos/${equipoId}`);
  }
  public actualizarEquipo(equipo: any) {
    return this.http.put(`${baserUrl}/equipos/`, equipo);
  }
}