import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class SocioService {

  constructor(private http:HttpClient) { }


  public listarSocios(){
    return this.http.get(`${baserUrl}/socio/`);
  }
  public agregarSocio(socio:any){
    return this.http.post(`${baserUrl}/socio/`, socio);
  }
  public eliminarSocio(socioId: any){
    return this.http.delete(`${baserUrl}/socio/${socioId}`);
  }
  public obtenerSocio(socioId:any){
    return this.http.get(`${baserUrl}/socio/${socioId}`);
  }
  public actualizarSocio(socio:any){
    return this.http.put(`${baserUrl}/socio/`, socio);
  }
}
