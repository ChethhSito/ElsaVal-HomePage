import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class CasaService {

  constructor(private http:HttpClient) { }

  public listarCasas(){
    return this.http.get(`${baserUrl}/casa/`);
  }
  public agregarCasa(casa:any){
    return this.http.post(`${baserUrl}/casa/`, casa);
  }
  public eliminarCasa(casaId:any){
    return this.http.delete(`${baserUrl}/casa/${casaId}`)
  }
  public obtenerCasa(casaId:any){
    return this.http.get(`${baserUrl}/casa/${casaId}`);
  }
  public actualizarCasa(casa:any){
    return this.http.put(`${baserUrl}/casa/`, casa);
  }

}
