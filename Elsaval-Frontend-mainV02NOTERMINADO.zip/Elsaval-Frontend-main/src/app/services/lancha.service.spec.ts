import { TestBed } from '@angular/core/testing';

import { LanchaService } from './lancha.service';

describe('LanchaService', () => {
  let service: LanchaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(LanchaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
