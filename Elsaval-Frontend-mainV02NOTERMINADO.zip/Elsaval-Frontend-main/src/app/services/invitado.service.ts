import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class InvitadoService {

  constructor(private http:HttpClient) { }


  public listarInvitados(){
    return this.http.get(`${baserUrl}/invitados/`);
  }
  public agregarInvitado(invitado:any){
    return this.http.post(`${baserUrl}/invitados/`, invitado);
  }
  public eliminarInvitado(invitadoId: any){
    return this.http.delete(`${baserUrl}/invitados/${invitadoId}`);
  }
  public obtenerInvitado(invitadoId:any){
    return this.http.get(`${baserUrl}/invitados/${invitadoId}`);
  }
  public actualizarInvitado(invitado:any){
    return this.http.put(`${baserUrl}/invitados/`, invitado);
  }
}
