import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class VehiculosService {

  constructor(private http: HttpClient){}

  public listarVehiculos(){
    return this.http.get(`${baserUrl}/vehiculo/`);
  }
  public agregarVehiculo(vehiculo:any){
    return this.http.post(`${baserUrl}/vehiculo/`, vehiculo)
  }
  public eliminarVehiculo(vehiculoId:any){
    return this.http.delete(`${baserUrl}/vehiculo/${vehiculoId}`)
  }
  public obtenerVehiculo(vehiculoId:any){
    return this.http.get(`${baserUrl}/vehiculo/${vehiculoId}`);
  }
  public actualizarVehiculo(vehiculo:any){
    return this.http.put(`${baserUrl}/vahiculo/`, vehiculo);
  }
}
