let baserUrl = 'http://localhost:8080'
export default baserUrl;