import { TestBed } from '@angular/core/testing';

import { InfoempleadoService } from './infoempleado.service';

describe('InfoempleadoService', () => {
  let service: InfoempleadoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InfoempleadoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
