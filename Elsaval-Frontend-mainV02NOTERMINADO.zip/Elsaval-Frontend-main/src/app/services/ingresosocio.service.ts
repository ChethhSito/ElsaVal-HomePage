import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class IngresosocioService {

  constructor(private http:HttpClient) { }

  public listarIngresoSocio(){
    return this.http.get(`${baserUrl}/ingresosocio/`);
  }
  public agregarIngresoSocio(ingresosocio:any){
    return this.http.post(`${baserUrl}/ingresosocio/`, ingresosocio);
  }
}
