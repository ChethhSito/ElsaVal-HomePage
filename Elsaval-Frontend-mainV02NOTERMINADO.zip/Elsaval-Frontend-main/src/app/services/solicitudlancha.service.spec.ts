import { TestBed } from '@angular/core/testing';

import { SolicitudLanchaService } from './solicitudlancha.service';

describe('SolicitudlanchaService', () => {
  let service: SolicitudLanchaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(SolicitudLanchaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
