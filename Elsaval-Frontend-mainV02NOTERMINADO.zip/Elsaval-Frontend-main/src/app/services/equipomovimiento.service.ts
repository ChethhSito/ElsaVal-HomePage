import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class EquipoMovimientoService {

  constructor(private http:HttpClient) { }

  public listarMovimientos(){
    return this.http.get(`${baserUrl}/equipomovimiento/`);
  }

  public agregarMovimiento(movimiento:any){
    return this.http.post(`${baserUrl}/equipomovimiento/`, movimiento);
  }

  public eliminarMovimiento(movimientoId:any){
    return this.http.delete(`${baserUrl}/equipomovimiento/${movimientoId}`);
  }
  public obtenerMovimiento(movimientoId:any){
    return this.http.get(`${baserUrl}/equipomovimiento/${movimientoId}`);
  }
  public actualizarMovimiento(movimiento:any){
    return this.http.put(`${baserUrl}/equipomovimiento/`, movimiento);
  }
}
