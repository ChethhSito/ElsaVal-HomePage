import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import baserUrl from './helper';

@Injectable({
  providedIn: 'root'
})
export class AlmacenService {

  constructor(private http:HttpClient) { }

  public listarAlmacenes(){
    return this.http.get(`${baserUrl}/almacen/`);
  }

  public agregarAlmacenes(almacen:any){
    return this.http.post(`${baserUrl}/almacen/`,almacen);
  }
}
