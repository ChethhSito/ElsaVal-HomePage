import { HttpClientModule } from '@angular/common/http';
import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { NavbarComponent } from './components/navbar/navbar.component';
import { SignupComponent } from './pages/signup/signup.component';
import { LoginComponent } from './pages/login/login.component';

import { MatSelectModule } from '@angular/material/select';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import {MatListModule} from '@angular/material/list';
import {MatButtonModule} from '@angular/material/button';
import {MatFormFieldModule} from '@angular/material/form-field';
import {MatInputModule} from '@angular/material/input';
import { FormsModule } from '@angular/forms';
import {MatSnackBarModule} from '@angular/material/snack-bar';

import {MatCardModule} from '@angular/material/card';
import {MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import { HomeComponent } from './pages/home/home.component';
import { authInterceptorProviders } from './services/auth.interceptor';
import { DashboardComponent } from './pages/admin/dashboard/dashboard.component';
import { UserDashboardComponent } from './pages/user/user-dashboard/user-dashboard.component';
import { ProfileComponent } from './pages/profile/profile.component';
import { SidebarComponent } from './pages/admin/sidebar/sidebar.component';
import { WelcomeComponent } from './pages/admin/welcome/welcome.component';
import { ViewAlmacenComponent } from './pages/admin/view-almacen/view-almacen.component';
import { AddAlmacenComponent } from './pages/admin/add-almacen/add-almacen.component';
import { MatDividerModule } from '@angular/material/divider';

import { CommonModule } from '@angular/common';
import  {MatExpansionModule } from "@angular/material/expansion";
import { ViewElementosComponent } from './pages/admin/view-elementos/view-elementos.component';
import { ViewUsuariosComponent } from './pages/admin/view-usuarios/view-usuarios.component';
import { AddElementoComponent } from './pages/admin/add-elemento/add-elemento.component';
import { ActualizarElementoComponent } from './pages/admin/actualizar-elemento/actualizar-elemento.component';
import { ActualizarUsuariosComponent } from './pages/admin/actualizar-usuarios/actualizar-usuarios.component';
import {MatDatepickerModule} from '@angular/material/datepicker';

import {MatNativeDateModule} from '@angular/material/core';
import { ViewEspejosComponent } from './pages/admin/view-espejos/view-espejos.component';
import { AddEspejosComponent } from './pages/admin/add-espejos/add-espejos.component';
import { ViewEmpleadoComponent } from './pages/admin/view-empleado/view-empleado.component';
import { AddEmpleadoComponent } from './pages/admin/add-empleado/add-empleado.component';
import { ActializarEmpleadoComponent } from './pages/admin/actializar-empleado/actializar-empleado.component';
import { DetalleEmpleadoComponent } from './pages/admin/detalle-empleado/detalle-empleado.component';
import { ViewSocioComponent } from './pages/admin/view-socio/view-socio.component';
import { AddSocioComponent } from './pages/admin/add-socio/add-socio.component';
import { ActualizarSocioComponent } from './pages/admin/actualizar-socio/actualizar-socio.component';
import { DetalleSocioComponent } from './pages/admin/detalle-socio/detalle-socio.component';
import { AddCasaComponent } from './pages/admin/add-casa/add-casa.component';
import { ViewCasaComponent } from './pages/admin/view-casa/view-casa.component';
import { ActualizarCasaComponent } from './pages/admin/actualizar-casa/actualizar-casa.component';
import { AddLanchasComponent } from './pages/admin/add-lanchas/add-lanchas.component';
import { ViewLanchasComponent } from './pages/admin/view-lanchas/view-lanchas.component';
import { ActualizarLanchasComponent } from './pages/admin/actualizar-lanchas/actualizar-lanchas.component';
import { DetalleLanchaComponent } from './pages/admin/detalle-lancha/detalle-lancha.component';
import { CarruselComponent } from './components/carrusel/carrusel.component';
import { InvitadosComponent } from './pages/user/invitados/invitados.component';
import { ProveedoresComponent } from './pages/user/proveedores/proveedores.component';
import { UserSidebarComponent } from './pages/user/user-sidebar/user-sidebar.component';
import { UserWelcomeComponent } from './pages/user/user-welcome/user-welcome.component';
import { MatDialog } from '@angular/material/dialog';
import { ViewSolicitudLanchaComponent } from './pages/user/view-solicitudlancha/view-solicitudlancha.component';
import { AddVehiculoComponent } from './pages/admin/add-vehiculo/add-vehiculo.component';
import { ViewVehiculosComponent } from './pages/admin/view-vehiculos/view-vehiculos.component';
import { AddIngresosocioComponent } from './pages/admin/add-ingresosocio/add-ingresosocio.component';
import { ViewIngresosocioComponent } from './pages/admin/view-ingresosocio/view-ingresosocio.component';
import { AddInvitadosComponent } from './pages/user/add-invitados/add-invitados.component';
import { ActualizarInvitadosComponent } from './pages/user/actualizar-invitados/actualizar-invitados.component';
import { AddProveedoresComponent } from './pages/user/add-proveedores/add-proveedores.component';
import { ImagenComponent } from './pages/admin/imagen/imagen.component';
import { ViewProductoComponent } from './pages/admin/view-producto/view-producto.component';
import { AddProductoComponent } from './pages/admin/add-producto/add-producto.component';
import { MinusProductoComponent} from './pages/admin/minus-producto/minus-producto.component';
import { PlusProductoComponent } from './pages/admin/plus-producto/plus-producto.component';
import { ActualizarVehiculosComponent } from './pages/admin/actualizar-vehiculos/actualizar-vehiculos.component';
import { ViewInvitadosComponent } from './pages/admin/view-invitados/view-invitados.component';
import { DetalleInvitadoComponent } from './pages/admin/detalle-invitado/detalle-invitado.component';
import { ViewProveedoresComponent } from './pages/admin/view-proveedores/view-proveedores.component';
import { ActualizarProveedorComponent } from './pages/admin/actualizar-proveedor/actualizar-proveedor.component';
import { DetalleVehiculoComponent } from './pages/admin/detalle-vehiculo/detalle-vehiculo.component';
import { ViewEquipoComponent } from './pages/admin/view-equipo/view-equipo.component';
import { AddEquipoComponent } from './pages/admin/add-equipo/add-equipo.component';
import { PlusEquipoComponent } from './pages/admin/plus-equipo/plus-equipo.component';
import { MinusEquipoComponent } from './pages/admin/minus-equipo/minus-equipo.component';








@NgModule({
  declarations: [
    AppComponent,
    NavbarComponent,
    SignupComponent,
    LoginComponent,
    HomeComponent,
    DashboardComponent,
    UserDashboardComponent,
    ProfileComponent,
    SidebarComponent,
    WelcomeComponent,
    ViewAlmacenComponent,
    AddAlmacenComponent,
    ViewElementosComponent,
    ViewUsuariosComponent,
    AddElementoComponent,
    ActualizarElementoComponent,
    ActualizarUsuariosComponent,
    ViewEspejosComponent,
    AddEspejosComponent,
    ViewEmpleadoComponent,
    AddEmpleadoComponent,
    ActializarEmpleadoComponent,
    DetalleEmpleadoComponent,
    ViewSocioComponent,
    AddSocioComponent,
    ActualizarSocioComponent,
    DetalleSocioComponent,
    AddCasaComponent,
    ViewCasaComponent,
    ActualizarCasaComponent,
    AddLanchasComponent,
    ViewLanchasComponent,
    ActualizarLanchasComponent,
    DetalleLanchaComponent,
    CarruselComponent,
    InvitadosComponent,
    UserSidebarComponent,
    UserWelcomeComponent,
    ViewSolicitudLanchaComponent,
    AddVehiculoComponent,
    ViewVehiculosComponent,
    AddIngresosocioComponent,
    ViewIngresosocioComponent,
    AddInvitadosComponent,
    ActualizarInvitadosComponent,
    ProveedoresComponent,
    AddProveedoresComponent,
    ImagenComponent,
    ViewProductoComponent,
    AddProductoComponent,
    PlusProductoComponent,
    MinusProductoComponent,
    ActualizarVehiculosComponent,
    ViewInvitadosComponent,
    DetalleInvitadoComponent,
    ViewProveedoresComponent,
    ActualizarProveedorComponent,
    DetalleVehiculoComponent,
    ViewEquipoComponent,
    AddEquipoComponent,
    PlusEquipoComponent,
    MinusEquipoComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    FormsModule,
    HttpClientModule,
    MatSnackBarModule,
    MatCardModule,
    MatToolbarModule,
    MatIconModule,
    MatListModule,
    CommonModule,
    MatExpansionModule,
    MatDividerModule,
    MatSlideToggleModule,
    MatSelectModule,
    MatDatepickerModule, 
    MatNativeDateModule,  
  ],
  exports: [MatToolbarModule,MatButtonModule,MatIconModule,MatExpansionModule],
  providers: [authInterceptorProviders, MatDialog],
  bootstrap: [AppComponent]
})
export class AppModule { }
