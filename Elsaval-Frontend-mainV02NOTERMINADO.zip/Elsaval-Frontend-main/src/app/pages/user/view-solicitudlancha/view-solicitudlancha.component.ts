import { Component, OnInit } from '@angular/core';
import { SolicitudLanchaService } from 'src/app/services/solicitudlancha.service';
import { Router } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-solicitudlancha',
  templateUrl: './view-solicitudlancha.component.html',
  styleUrls: ['./view-solicitudlancha.component.css']
})

export class ViewSolicitudLanchaComponent implements OnInit{
  solicitudesData = {
    socio: {
      socioId: 2,
    },
    fecha: new Date(),
    estado: {
      estadoId: 1,
    }
  }
  solicitudlanchas: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;

  constructor(private solicitudlanchaService:SolicitudLanchaService, private router: Router){}

  prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.solicitudlanchas.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }

  displayedSolicitudLancha():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.solicitudlanchas.slice(starIndex, endIndex);
  }

  ngOnInit(): void {
    this.solicitudlanchaService.listarSolicitudes().subscribe(
      (dato:any) => {
        this.solicitudlanchas = dato;
        this.calculateTotalPages();
        console.log(this.solicitudlanchas);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar las solicitudes','error');
      }
    )  
  }

  AddSolicitudLanchaComponent() {
    this.solicitudlanchaService.listarSolicitudes().subscribe(
      (solicitudes: any) => {
        const solicitudEnEspera = solicitudes.find((solicitud: any) => solicitud.estado.estadoId === 1);
  
        if (solicitudEnEspera) {
          Swal.fire('Solicitud en espera', 'Ya tienes una solicitud en espera. No se ha enviado una nueva solicitud.', 'info');
        } else {
          Swal.fire({
            title: 'Solicitud de Lancha',
            text: '¿Estás seguro que deseas solicitar tu lancha?',
            icon: 'question',
            showCancelButton: true,
            confirmButtonColor: '#103061',
            cancelButtonColor: '#A01919',
            confirmButtonText: 'Si',
            cancelButtonText: 'No'
          }).then((result) => {
            if (result.isConfirmed) {
              this.solicitudlanchaService.agregarSolicitud(this.solicitudesData).subscribe(
                (data) => {
                  console.log(data);
                  Swal.fire('Solicitud enviada', 'Se ha enviado la solicitud con éxito.', 'success');
                  this.solicitudesData = {
                    socio: {
                      socioId: 1, // CAMBIA POR EL SOCIO QUE ESTA LOGEADO
                    },
                    fecha: new Date(),
                    estado: {
                      estadoId: 1,
                    }
                  };
                  window.location.reload();
                },
                (error) => {
                  Swal.fire('Error', 'Error al guardar la informacion de la solicitud', 'error');
                }
              );
            }
          });
        }
      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar las solicitudes', 'error');
      }
    );
  }
}
