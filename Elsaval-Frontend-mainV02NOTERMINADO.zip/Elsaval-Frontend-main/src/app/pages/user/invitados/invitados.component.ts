import { Component, OnInit } from '@angular/core';
import { InvitadoService } from 'src/app/services/invitado.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-invitados',
  templateUrl: './invitados.component.html',
  styleUrls: ['./invitados.component.css']
})
export class InvitadosComponent implements OnInit{
  invitados: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
   constructor(private invitadosService:InvitadoService){}

   prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.invitados.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedInvitados():any[]{
    const startIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = startIndex + this.rowsPerPage;
    return this.invitados.slice(startIndex, endIndex);
  }
  ngOnInit(): void {
    this.invitadosService.listarInvitados().subscribe(
      (dato:any) => {
        this.invitados = dato;
        this.calculateTotalPages();
        console.log(this.invitados);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los invitados','error');
      }
    )  
  }
  eliminarInvitado(invitadoId:any){
    Swal.fire({
      title:'Eliminar Invitado',
      text:'¿Estas seguro de eliminar la informacion de la lista?',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.invitadosService.eliminarInvitado(invitadoId).subscribe(
          (data)=>{
            this.invitados = this.invitados.filter((invitado:any)=> invitado.invitadoId != invitadoId);
            Swal.fire('Invitado eliminado','El invitado ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar el invitado de la base de datos','error');
          }
        )
      }
    })
  }
}

