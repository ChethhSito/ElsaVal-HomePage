import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { InvitadoService } from 'src/app/services/invitado.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-invitados',
  templateUrl: './add-invitados.component.html',
  styleUrls: ['./add-invitados.component.css']
})
export class AddInvitadosComponent implements OnInit {

  invitadosData = {
    nombre: '',
    apellido: '',
    dni: '',
    numero: '',
    ncasa: '',
    fecha: new Date(),
  }
  casas = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
  fechaActual = this.invitadosData.fecha.toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric'
  });

  constructor(
    private snack: MatSnackBar,
    private invitadoService: InvitadoService,
    private router: Router) { }
  ngOnInit(): void {

  }
  guardarInformacion() {
    console.log(this.invitadosData);
    const letrasPattern = /^[A-Za-z\s]+$/;
    const dniPattern = /^\d{8}$/;
    const numeroPattern = /^(\d{7}|\d{9})$/;
    if (this.invitadosData.nombre.trim() === '' || this.invitadosData.nombre == null) {
      this.snack.open('El nombre del invitado es requerido', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.invitadosData.apellido.trim() === '' || this.invitadosData.apellido == null) {
      this.snack.open('El apellido del invitado es requerido', '', {
        duration: 3000
      });
      return;
    }
    if (!letrasPattern.test(this.invitadosData.nombre)) {
      this.snack.open('El nombre del invitado solo puede contener letras', '', {
        duration: 3000
      });
      return;
    }
  
    if (!letrasPattern.test(this.invitadosData.apellido)) {
      this.snack.open('El apellido del invitado solo puede contener letras', '', {
        duration: 3000
      });
      return;
    }
    if (this.invitadosData.dni.trim() === '' || this.invitadosData.dni == null) {
      this.snack.open('El DNI del invitado es requerido', '', {
        duration: 3000
      });
      return;
    }
    if (!dniPattern.test(this.invitadosData.dni) || this.invitadosData.dni.length !== 8) {
      this.snack.open('El DNI del invitado debe tener 8 caracteres numéricos', '', {
        duration: 3000
      });
      return;
    }
  
    if (this.invitadosData.numero.trim() === '' || this.invitadosData.numero == null) {
      this.snack.open('El número del invitado es requerido', '', {
        duration: 3000
      });
      return;
    }
    if (!numeroPattern.test(this.invitadosData.numero) || (this.invitadosData.numero.length !== 7 && this.invitadosData.numero.length !== 9)) {
      this.snack.open('El número del invitado debe tener 7 (número de casa) o 9 (número de celular) caracteres numéricos', '', {
        duration: 3000
      });
      return;
    }
    this.invitadoService.agregarInvitado(this.invitadosData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Ingreso invitado guardado', 'El ingreso de invitado ha sido guardado con exito', 'success');
        this.invitadosData = {
          nombre: '',
          apellido: '',
          dni: '',
          numero: '',
          ncasa: '1',
          fecha: new Date(),
        }
        this.router.navigate(['/user/invitados'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la informacion del invitado', 'error');
      }
    )
  }
}
