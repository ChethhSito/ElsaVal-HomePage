import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddInvitadosComponent } from './add-invitados.component';

describe('AddInvitadosComponent', () => {
  let component: AddInvitadosComponent;
  let fixture: ComponentFixture<AddInvitadosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddInvitadosComponent]
    });
    fixture = TestBed.createComponent(AddInvitadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
