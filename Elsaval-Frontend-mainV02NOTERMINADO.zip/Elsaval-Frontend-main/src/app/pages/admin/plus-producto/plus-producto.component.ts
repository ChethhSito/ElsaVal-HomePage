import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { ElementoService } from 'src/app/services/elemento.service';
import { MovimientoService } from 'src/app/services/movimiento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-plus-producto',
  templateUrl: './plus-producto.component.html',
  styleUrls: ['./plus-producto.component.css']
})
export class PlusProductoComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private elementoService: ElementoService,
    private movimientoService: MovimientoService,
    private router: Router
  ) { }

  elementoId = 0;
  elemento: any;
  cantidadAgregar: number = 0;

  ngOnInit(): void {
    this.elementoId = this.route.snapshot.params['elemento_id'];
    this.elementoService.obtenerElemento(this.elementoId).subscribe(
      (data) => {
        this.elemento = data;
        console.log(this.elemento);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  volverAProductos() {
    this.router.navigate(['/admin/productos']); 
  }

  public actualizarDatos() {
    if (this.validarProducto()) {
      const nuevaCantidad = this.elemento.cantidad + this.cantidadAgregar;
      this.elemento.cantidad = nuevaCantidad;
  
      this.elementoService.actualizarElemento(this.elemento).subscribe(
        (data) => {
          console.log('Elemento actualizado:', this.elemento);
  
          const movimiento = {
            cantidad: this.cantidadAgregar,
            estado: 'Agregado',
            fecha: this.getCurrentDate(),
            almacen: {
              almacenId: this.elemento.almacen.almacenId,
            },
            producto: {
              elemento_id: this.elemento.elemento_id,
            },
          };

          console.log('Movimiento:', movimiento);
  
          this.movimientoService.agregarMovimiento(movimiento).subscribe(
            (dataMovimiento) => {
              Swal.fire('Cantidad actualizada y movimiento registrado', 'La cantidad ha sido actualizada y el movimiento ha sido registrado con éxito', 'success').then(
                (e) => {
                  this.router.navigate(['/admin/productos']);
                }
              );
            },
            (errorMovimiento) => {
              Swal.fire('Error en el sistema', 'No se ha podido registrar el movimiento', 'error');
              console.log(errorMovimiento);
            }
          );
        },
        (error) => {
          Swal.fire('Error en el sistema', 'No se ha podido actualizar la información del producto', 'error');
          console.log(error);
        }
      );
    }
  }

  validarProducto() {
    if (this.cantidadAgregar <= 0) {
      Swal.fire('Error', 'La cantidad debe ser un número mayor que 0', 'error');
      return false;
    }
    return true;
  }

  getCurrentDate(): string {
    const currentDate = new Date();
    return currentDate.toISOString();
  }
}