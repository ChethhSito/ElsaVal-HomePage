import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PlusProductoComponent } from './plus-producto.component';

describe('PlusProductoComponent', () => {
  let component: PlusProductoComponent;
  let fixture: ComponentFixture<PlusProductoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PlusProductoComponent]
    });
    fixture = TestBed.createComponent(PlusProductoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
