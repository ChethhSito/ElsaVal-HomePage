import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EspejoService } from 'src/app/services/espejo.service';
import { InvitadoService } from 'src/app/services/invitado.service';
import { SocioService } from 'src/app/services/socio.service';

@Component({
  selector: 'app-detalle-invitado',
  templateUrl: './detalle-invitado.component.html',
  styleUrls: ['./detalle-invitado.component.css']
})
export class DetalleInvitadoComponent implements OnInit{
  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private invitadoService:InvitadoService,
    private espejoService: EspejoService,
    private router: Router) { }

  invitadoId = 0;
  invitado: any;
  espejos: any;
  
  ngOnInit(): void {
    this.invitadoId = this.route.snapshot.params['invitadoId'];
    this.invitadoService.obtenerInvitado(this.invitadoId).subscribe(
      (data) => {
        this.invitado = data;
        console.log(this.invitado)
      },
      (error)=> {
        console.log(error);
      }
    )

    this.espejoService.listarEspejos().subscribe(
      (data:any) =>{
        this.espejos = data;
      },
      (error)=>{
        alert('Error al cargar los usuarios')
      }
    )
  }
}
