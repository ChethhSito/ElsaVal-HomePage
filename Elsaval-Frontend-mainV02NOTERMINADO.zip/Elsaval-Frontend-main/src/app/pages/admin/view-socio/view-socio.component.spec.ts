import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewSocioComponent } from './view-socio.component';

describe('ViewSocioComponent', () => {
  let component: ViewSocioComponent;
  let fixture: ComponentFixture<ViewSocioComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewSocioComponent]
    });
    fixture = TestBed.createComponent(ViewSocioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
