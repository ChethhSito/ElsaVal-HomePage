import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEspejosComponent } from './view-espejos.component';

describe('ViewEspejosComponent', () => {
  let component: ViewEspejosComponent;
  let fixture: ComponentFixture<ViewEspejosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewEspejosComponent]
    });
    fixture = TestBed.createComponent(ViewEspejosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
