import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { VehiculosService } from 'src/app/services/vehiculos.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-vehiculo',
  templateUrl: './add-vehiculo.component.html',
  styleUrls: ['./add-vehiculo.component.css']
})
export class AddVehiculoComponent implements OnInit{

  estados = ['Disponible', 'No Disponible', 'En mantenimiento', 'Averiada', 'En Uso'];

  socios: any = [];

  vehiculoData = {
    modelo: '',
    placa: '',
    marca: '',
    activo: true,
    estado: '',
    color: '',
  }
  constructor(
    private snack: MatSnackBar,
    private vehiculoService: VehiculosService,
    private router: Router) { }
  
  ngOnInit(): void {
    throw new Error('Method not implemented.');
  }

  guardarInformacion() {
    console.log(this.vehiculoData);
    if (this.vehiculoData.modelo.trim() == '' || this.vehiculoData.modelo == null) {
      this.snack.open('El elmodelo del vehiculo es requerido', '', {
        duration: 4000
      });
      return;
    }
    this.vehiculoService.agregarVehiculo(this.vehiculoData).subscribe(
      (data) => {
        Swal.fire('Lancha Guardado', 'La lancha ha sido guardado con exito', 'success');
        this.vehiculoData = {
          modelo: '',
          placa: '',
          marca: '',
          activo: true,
          estado: '',
          color: '',
        }
        this.router.navigate(['/admin/vehiculos'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la vehiculos en el sistema','error');
      }
    )
  }

}
