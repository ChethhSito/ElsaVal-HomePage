import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EspejoService } from 'src/app/services/espejo.service';
import { SocioService } from 'src/app/services/socio.service';

@Component({
  selector: 'app-detalle-socio',
  templateUrl: './detalle-socio.component.html',
  styleUrls: ['./detalle-socio.component.css']
})
export class DetalleSocioComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private espejoService: EspejoService,
    private router: Router) { }

  socioId = 0;
  socio: any;
  espejos: any;
  
  ngOnInit(): void {
    this.socioId = this.route.snapshot.params['socioId'];
    this.socioService.obtenerSocio(this.socioId).subscribe(
      (data) => {
        this.socio = data;
        console.log(this.socio)
      },
      (error)=> {
        console.log(error);
      }
    )

    this.espejoService.listarEspejos().subscribe(
      (data:any) =>{
        this.espejos = data;
      },
      (error)=>{
        alert('Error al cargar los usuarios')
      }
    )
  }

}
