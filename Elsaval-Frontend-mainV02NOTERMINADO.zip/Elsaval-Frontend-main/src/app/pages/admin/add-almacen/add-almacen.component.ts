import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { AlmacenService } from 'src/app/services/almacen.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-almacen',
  templateUrl: './add-almacen.component.html',
  styleUrls: ['./add-almacen.component.css']
})
export class AddAlmacenComponent  implements OnInit{
  almacen={
    titulo: '',
    descripcion: ''
  }
  
  constructor(private almacenService:AlmacenService, private snack:MatSnackBar, private router:Router){

  }
  ngOnInit(): void {
    
  }
  formSubmit(){
    if(this.almacen.titulo.trim() == '' || this.almacen.titulo == null){
      this.snack.open("El titulo es requerido !!",'',{
        duration:3000
      })
      return;
    }
    this.almacenService.agregarAlmacenes(this.almacen).subscribe(
      (dato:any) => {
        this.almacen.titulo = '';
        this.almacen.descripcion = '';
        Swal.fire('Almacen agregado','El almacen ha sido agregado con exito', 'success');
        this.router.navigate(['/admin/almacenes']);
      },
      (error) => {
        console.log(error);
        Swal.fire('Error','Error al guardar el almacen','error')
      }
    )
  }
}
