import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddIngresosocioComponent } from './add-ingresosocio.component';

describe('AddIngresosocioComponent', () => {
  let component: AddIngresosocioComponent;
  let fixture: ComponentFixture<AddIngresosocioComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddIngresosocioComponent]
    });
    fixture = TestBed.createComponent(AddIngresosocioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
