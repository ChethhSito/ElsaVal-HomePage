import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { IngresosocioService } from 'src/app/services/ingresosocio.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-ingresosocio',
  templateUrl: './add-ingresosocio.component.html',
  styleUrls: ['./add-ingresosocio.component.css']
})
export class AddIngresosocioComponent implements OnInit{
  tipos = ['Ingreso', 'Salida'];

  socios: any = [];

  ingresosocioData = {
    tipo: '',
    fecha: new Date(),
    socio: {
      socioId: ''
    }
  }
  fechaActual = this.ingresosocioData.fecha.toLocaleDateString('es-ES', {
    day: 'numeric',
    month: 'numeric',
    year: 'numeric'
  });

  constructor(private socioService: SocioService,
    private snack: MatSnackBar,
    private ingresosocioService: IngresosocioService,
    private router: Router) { }

    ngOnInit(): void {
      this.socioService.listarSocios().subscribe(
        (dato: any) => {
          this.socios = dato;
          console.log(this.socios);
        }, (error) => {
          console.log(error);
          Swal.fire('Error !!', 'Error al cargar los datos', 'error')
        }
      )
    }
    guardarInformacion() {

      this.ingresosocioService.agregarIngresoSocio(this.ingresosocioData).subscribe(
        (data) => {
          Swal.fire('Ingreso Registrado', 'Registro guardado con exito', 'success');
          this.ingresosocioData = {
            tipo: '',
            fecha: new Date(),
            socio: {
              socioId: ''
            }
          }
          this.router.navigate(['/admin/ingresosocios'])
        },
        (error) => {
          Swal.fire('Error', 'Error al guardar resgistro en el sistema','error');
        }
      )
    }
}
