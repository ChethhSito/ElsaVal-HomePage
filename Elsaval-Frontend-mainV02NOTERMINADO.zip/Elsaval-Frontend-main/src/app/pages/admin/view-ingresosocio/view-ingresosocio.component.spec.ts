import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewIngresosocioComponent } from './view-ingresosocio.component';

describe('ViewIngresosocioComponent', () => {
  let component: ViewIngresosocioComponent;
  let fixture: ComponentFixture<ViewIngresosocioComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewIngresosocioComponent]
    });
    fixture = TestBed.createComponent(ViewIngresosocioComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
