import { Component, OnInit } from '@angular/core';
import { LanchaService } from 'src/app/services/lancha.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-lanchas',
  templateUrl: './view-lanchas.component.html',
  styleUrls: ['./view-lanchas.component.css']
})
export class ViewLanchasComponent implements OnInit {

  lanchas: any = [

  ]
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;

  constructor(private lanchaService: LanchaService) { }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.lanchas.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = 1;
    }
  }
  displayedLanchas(): any[] {
    const starIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.lanchas.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.lanchaService.listarLanchas().subscribe(
      (dato: any) => {
        this.lanchas = dato;
        this.calculateTotalPages();
        console.log(this.lanchas);

      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar los elementos del almacen', 'error');
      }
    )
  }
  eliminarLancha(lanchaId:any){
    Swal.fire({
      title:'Eliminar lancha',
      text:'¿Estas seguro de eliminar lancha seleccionado',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.lanchaService.eliminarLancha(lanchaId).subscribe(
          (data)=>{
            this.lanchas = this.lanchas.filter((lancha:any)=> lancha.lanchaId != lanchaId);
            Swal.fire('Elemento eliminado','La lancha ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar lancha de la base de datos','error');
          }
        )
      }
    })
  }
}
