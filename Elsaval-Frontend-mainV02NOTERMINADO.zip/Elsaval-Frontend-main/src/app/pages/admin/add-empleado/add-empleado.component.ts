import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { EspejoService } from 'src/app/services/espejo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-empleado',
  templateUrl: './add-empleado.component.html',
  styleUrls: ['./add-empleado.component.css']
})
export class AddEmpleadoComponent implements OnInit {
  espejos: any = [];


  empleadosData = {
    apellidos: '',
    celemergencia: '',
    celular: '',
    correo: '',
    dni: '',
    licencianauti: '',
    licenciavehi: '',
    nombres: '',
    espejo: {
      espejoId: ''
    }
  }
  constructor(private espejoService: EspejoService,
    private snack: MatSnackBar,
    private empleadoService: EmpleadosService,
    private router: Router) { }
  ngOnInit(): void {
    this.espejoService.listarEspejos().subscribe(
      (dato: any) => {
        this.espejos = dato;
        console.log(this.espejos);
      }, (error) => {
        console.log(error);
        Swal.fire('Error !!', 'Error al cargar los datos', 'error')
      }
    )

  }
  guardarInformacion() {
    console.log(this.empleadosData);
    if (this.empleadosData.nombres.trim() == '' || this.empleadosData.nombres == null
    ) {
      this.snack.open('Para llenar el formulario los Nombres, DNI, Seleccion del Usuario son requeridos', '', {
        duration: 4000
      });
      return;
    }    

    this.empleadoService.agregarEmpleado(this.empleadosData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Empleado guardado', 'El empleado ha sido guardado con exito', 'success');
        this.empleadosData = {
          apellidos: '',
          celemergencia: '',
          celular: '',
          correo: '',
          dni: '',
          licencianauti: '',
          licenciavehi: '',
          nombres: '',
          espejo: {
            espejoId: ''
          }
        }
        this.router.navigate(['/admin/empleados'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar el informacion del empleado ', 'error');
      }
    )
  }

}
