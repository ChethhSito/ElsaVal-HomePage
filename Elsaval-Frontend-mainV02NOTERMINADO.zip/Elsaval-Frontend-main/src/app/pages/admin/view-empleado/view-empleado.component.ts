import { Component, OnInit } from '@angular/core';
import { EmpleadosService } from 'src/app/services/empleados.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-empleado',
  templateUrl: './view-empleado.component.html',
  styleUrls: ['./view-empleado.component.css']
})
export class ViewEmpleadoComponent implements OnInit{
  empleados: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;

  constructor(private empleadoService:EmpleadosService){}

  prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.empleados.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }

  displayedEmpleados():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.empleados.slice(starIndex, endIndex);
  }

  ngOnInit(): void {
    this.empleadoService.listarEmpleados().subscribe(
      (dato:any) => {
        this.empleados = dato;
        this.calculateTotalPages();
        console.log(this.empleados);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los empleados','error');
      }
    )  
  }
  eliminarEmpleado(empleadoId:any){
    Swal.fire({
      title:'Eliminar elemento',
      text:'¿Estas seguro de eliminar empleado de la lista?',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.empleadoService.eliminarEmpleado(empleadoId).subscribe(
          (data)=>{
            this.empleados = this.empleados.filter((empleado:any)=> empleado.empleadoId != empleadoId);
            Swal.fire('Empleado eliminado','El empleado ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar elemento de la base de datos','error');
          }
        )
      }
    })
  }

}
