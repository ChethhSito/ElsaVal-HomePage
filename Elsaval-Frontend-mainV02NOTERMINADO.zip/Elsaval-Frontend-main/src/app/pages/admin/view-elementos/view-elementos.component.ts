import { Component, OnInit } from '@angular/core';
import { ElementoService } from 'src/app/services/elemento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-elementos',
  templateUrl: './view-elementos.component.html',
  styleUrls: ['./view-elementos.component.css']
})
export class ViewElementosComponent implements OnInit{
  
  elementos: any=[

  ]
  currentPage = 1;
  rowsPerPage=10;
  totalPages= 0;
  
  constructor(private elementoService:ElementoService){}

  prevPage():void{
    if(this.currentPage > 1){
      this.currentPage--;
    }
  }

  nextPage():void{
    if(this.currentPage < this.totalPages){
      this.currentPage++;
    }
  }

  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.elementos.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedElementos():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.elementos.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.elementoService.listarElementos().subscribe(
      (dato:any) => {
        this.elementos = dato;
        this.calculateTotalPages();
        console.log(this.elementos);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar los elementos del almacen','error');
      }
    )  
  }
  eliminarElemento(elementoId:any){
    Swal.fire({
      title:'Eliminar elemento',
      text:'¿Estas seguro de eliminar elemento agregado?',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.elementoService.eliminarElemento(elementoId).subscribe(
          (data)=>{
            this.elementos = this.elementos.filter((elemento:any)=> elemento.elementoId != elementoId);
            Swal.fire('Elemento eliminado','El elemento ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar elemento de la base de datos','error');
          }
        )
      }
    })
  }
}
