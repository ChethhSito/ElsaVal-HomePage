import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewElementosComponent } from './view-elementos.component';

describe('ViewElementosComponent', () => {
  let component: ViewElementosComponent;
  let fixture: ComponentFixture<ViewElementosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewElementosComponent]
    });
    fixture = TestBed.createComponent(ViewElementosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
