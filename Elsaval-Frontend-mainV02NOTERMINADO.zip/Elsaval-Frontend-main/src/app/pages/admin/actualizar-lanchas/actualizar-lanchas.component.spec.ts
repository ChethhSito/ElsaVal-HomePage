import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarLanchasComponent } from './actualizar-lanchas.component';

describe('ActualizarLanchasComponent', () => {
  let component: ActualizarLanchasComponent;
  let fixture: ComponentFixture<ActualizarLanchasComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActualizarLanchasComponent]
    });
    fixture = TestBed.createComponent(ActualizarLanchasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
