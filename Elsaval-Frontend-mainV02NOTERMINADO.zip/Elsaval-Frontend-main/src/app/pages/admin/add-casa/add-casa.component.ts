import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { CasaService } from 'src/app/services/casa.service';
import { SocioService } from 'src/app/services/socio.service';
import { EmpleadosService } from 'src/app/services/empleados.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-casa',
  templateUrl: './add-casa.component.html',
  styleUrls: ['./add-casa.component.css']
})
export class AddCasaComponent implements OnInit {
  estados = ['Disponible', 'En mantenimiento', 'Deshabitado'];
  socios: any = [];
  empleados: any = [];

  casasData = {
    ncasa: '',
    nhabitantes: '',
    telefonofijo: '',
    estadocasa: '',
    empleado: {
      empleadoId: ''
    }
  }
  constructor(private socioService: SocioService,
    private snack: MatSnackBar,
    private empleadoService: EmpleadosService,
    private casaService: CasaService,
    private router: Router) { }

  ngOnInit(): void {
    this.empleadoService.listarEmpleados().subscribe(
      (dato: any) => {
        this.empleados = dato;
        console.log(this.socios);
      }, (error) => {
        console.log(error);
        Swal.fire('Error !!', 'Error al cargar los datos', 'error')
      }
    )
  }
  guardarInformacion() {
    console.log(this.casasData);
    if (this.casasData.ncasa.trim() == '' || this.casasData.ncasa == null) {
      this.snack.open('El numero de la casa es requerido', '', {
        duration: 3000
      });
      return;
    }
    this.casaService.agregarCasa(this.casasData).subscribe(
      (data) => {
        console.log(data);
        Swal.fire('Empleado guardado', 'La casa ha sido guardado con exito', 'success');
        this.casasData = {
          ncasa: '',
          nhabitantes: '',
          telefonofijo: '',
          estadocasa: '',
          empleado: {
            empleadoId: ''
          }
        }
        this.router.navigate(['/admin/casas'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la casa en el sistema', 'error');
      }
    )
  }

}
