import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCasaComponent } from './add-casa.component';

describe('AddCasaComponent', () => {
  let component: AddCasaComponent;
  let fixture: ComponentFixture<AddCasaComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddCasaComponent]
    });
    fixture = TestBed.createComponent(AddCasaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
