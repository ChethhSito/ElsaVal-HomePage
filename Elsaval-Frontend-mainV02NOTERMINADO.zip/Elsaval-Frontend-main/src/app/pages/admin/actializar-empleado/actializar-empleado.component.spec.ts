import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActializarEmpleadoComponent } from './actializar-empleado.component';

describe('ActializarEmpleadoComponent', () => {
  let component: ActializarEmpleadoComponent;
  let fixture: ComponentFixture<ActializarEmpleadoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActializarEmpleadoComponent]
    });
    fixture = TestBed.createComponent(ActializarEmpleadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
