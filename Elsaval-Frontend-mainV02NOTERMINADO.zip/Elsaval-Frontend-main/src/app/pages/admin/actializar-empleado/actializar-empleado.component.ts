import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EmpleadosService } from 'src/app/services/empleados.service';
import { EspejoService } from 'src/app/services/espejo.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actializar-empleado',
  templateUrl: './actializar-empleado.component.html',
  styleUrls: ['./actializar-empleado.component.css']
})
export class ActializarEmpleadoComponent implements OnInit {

  constructor(
    private route: ActivatedRoute,
    private empleadoService: EmpleadosService,
    private espejoService: EspejoService,
    private router: Router) { }

  empleadoId = 0;
  empleado: any;
  espejos: any;

  ngOnInit():void{
    this.empleadoId = this.route.snapshot.params['empleadoId'];
    this.empleadoService.obtenerEmpleado(this.empleadoId).subscribe(
      (data) => {
        this.empleado = data;
        console.log(this.empleado)
      },
      (error)=> {
        console.log(error);
      }
    )

    this.espejoService.listarEspejos().subscribe(
      (data:any) =>{
        this.espejos = data;
      },
      (error)=>{
        alert('Error al cargar los usuarios')
      }
    )
  }
  public actualizarDatos(){
    this.empleadoService.actualizarEmpleado(this.empleado).subscribe(
      (data) => {
          Swal.fire('Elemento actualizado','El empleado ha sido actualizado con exito', 'success').then(
            (e)=> {
              this.router.navigate(['/admin/empleados']);
            }
          );
      },
      (error) =>{
        Swal.fire('Error en el sistema','No se ha podido actualizar la infomacion del empleado', 'error');
        console.log(error);
      }
    )
  }


}
