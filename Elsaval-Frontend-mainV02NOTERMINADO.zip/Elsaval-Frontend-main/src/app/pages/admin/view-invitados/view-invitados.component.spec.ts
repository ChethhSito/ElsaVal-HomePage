import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewInvitadosComponent } from './view-invitados.component';

describe('ViewInvitadosComponent', () => {
  let component: ViewInvitadosComponent;
  let fixture: ComponentFixture<ViewInvitadosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewInvitadosComponent]
    });
    fixture = TestBed.createComponent(ViewInvitadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
