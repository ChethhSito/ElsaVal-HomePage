import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CasaService } from 'src/app/services/casa.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-casa',
  templateUrl: './actualizar-casa.component.html',
  styleUrls: ['./actualizar-casa.component.css']
})
export class ActualizarCasaComponent implements OnInit{
  estados = ['Disponible', 'En mantenimiento', 'Deshabitado'];
  constructor(
    private route: ActivatedRoute,
    private socioService: SocioService,
    private casasService: CasaService,
    private router: Router) { }

  casaId = 0;
  casa: any;
  socios: any;
  ngOnInit(): void {
    this.casaId = this.route.snapshot.params['casaId'];
    this.casasService.obtenerCasa(this.casaId).subscribe(
      (data) => {
        this.casa = data;
        console.log(this.casa)
      },
      (error) => {
        console.log(error);
      }
    )

    this.socioService.listarSocios().subscribe(
      (data: any) => {
        this.socios = data;
      },
      (error) => {
        alert('Error al cargar los socios')
      }
    )
  }

  public actualizarDatos(){
    this.casasService.actualizarCasa(this.casa).subscribe(
      (data) => {
          Swal.fire('Socio actualizado','La casa ha sido actualizado con exito', 'success').then(
            (e)=> {
              this.router.navigate(['/admin/casas']);
            }
          );
      },
      (error) =>{
        Swal.fire('Error en el sistema','No se ha podido actualizar la infomacion de la casa', 'error');
        console.log(error);
      }
    )
  }
}
