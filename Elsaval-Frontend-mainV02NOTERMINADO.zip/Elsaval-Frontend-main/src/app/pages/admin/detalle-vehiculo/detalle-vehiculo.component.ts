import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { VehiculosService } from 'src/app/services/vehiculos.service';

@Component({
  selector: 'app-detalle-vehiculo',
  templateUrl: './detalle-vehiculo.component.html',
  styleUrls: ['./detalle-vehiculo.component.css']
})
export class DetalleVehiculoComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private vehiculoService: VehiculosService,
    private router: Router) { }

    vehiculoId = 0;
    vehiculo: any;

    ngOnInit(): void {
      this.vehiculoId = this.route.snapshot.params['vehiculoId'];
      this.vehiculoService.obtenerVehiculo(this.vehiculoId).subscribe(
        (data) => {
          this.vehiculo = data;
          console.log(this.vehiculo)
        },
        (error)=> {
          console.log(error);
        }
        )
    }
}
