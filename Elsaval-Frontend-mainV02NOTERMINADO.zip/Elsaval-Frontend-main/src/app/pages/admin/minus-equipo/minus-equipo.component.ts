import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { EquipoService } from 'src/app/services/equipo.service';
import { EquipoMovimientoService } from 'src/app/services/equipomovimiento.service';
import { EmpleadosService } from 'src/app/services/empleados.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-minus-equipo',
  templateUrl: './minus-equipo.component.html',
  styleUrls: ['./minus-equipo.component.css']
})
export class MinusEquipoComponent implements OnInit{

  constructor(
    private route: ActivatedRoute,
    private empleadoService: EmpleadosService,
    private equipoService: EquipoService,
    private movimientoService: EquipoMovimientoService,
    private router: Router
  ) { }

  equipo_id = 0;
  empleados: any = [];
  equipo: any;
  cantidadRetirar: number = 0;
  empleadoSeleccionado: number = 0; 

  ngOnInit(): void {
    this.equipo_id = this.route.snapshot.params['equipo_id'];
    this.empleadoService.listarEmpleados().subscribe(
      (data) => {
        this.empleados = data;
        console.log(this.empleados);
      },
      (error) => {
        console.log(error);
      }
    );
    this.equipoService.obtenerEquipo(this.equipo_id).subscribe(
      (data) => {
        this.equipo = data;
        console.log(this.equipo);
      },
      (error) => {
        console.log(error);
      }
    );
  }

  volverAProductos() {
    this.router.navigate(['/admin/equipos']); 
  }

  public actualizarDatos() {
    if (this.validarProducto()) {
      const nuevaCantidad = this.equipo.cantidad - this.cantidadRetirar;
      this.equipo.cantidad = nuevaCantidad;
  
      this.equipoService.actualizarEquipo(this.equipo).subscribe(
        (data) => {
          console.log('Equipo actualizado:', this.equipo);
      
          const movimiento = {
            cantidad: this.cantidadRetirar,
            estado: 'Retirado',
            fecha: this.getCurrentDate(),
            empleado: {
              empleadoId: this.empleadoSeleccionado,
            },
            equipo: {
              equipoId: this.equipo.equipoId,
            },
          };
      
          console.log('Movimiento:', movimiento);

          console.log('Movimiento:', movimiento);
  
          this.movimientoService.agregarMovimiento(movimiento).subscribe(
            (dataMovimiento) => {
              Swal.fire('Cantidad actualizada y movimiento registrado', 'La cantidad ha sido actualizada y el movimiento ha sido registrado con éxito', 'success').then(
                (e) => {
                  this.router.navigate(['/admin/equipos']);
                }
              );
            },
            (errorMovimiento) => {
              Swal.fire('Error en el sistema', 'No se ha podido registrar el movimiento', 'error');
              console.log(errorMovimiento);
            }
          );
        },
        (error) => {
          Swal.fire('Error en el sistema', 'No se ha podido actualizar la información del producto', 'error');
          console.log(error);
        }
      );
    }
  }

  validarProducto() {
    if (this.cantidadRetirar <= 0) {
      Swal.fire('Error', 'La cantidad debe ser un número mayor que 0', 'error');
      return false;
    }
    if (this.cantidadRetirar > this.equipo.cantidad) {
      Swal.fire('Error', 'La cantidad a retirar no puede ser mayor al stock actual', 'error');
      return false;
    }
    if(this.empleadoSeleccionado == 0){
      Swal.fire('Error', 'Debe seleccionar un empleado', 'error');
      return false;
    }
    return true;
  }

  getCurrentDate(): string {
    const currentDate = new Date();
    return currentDate.toISOString();
  }
}