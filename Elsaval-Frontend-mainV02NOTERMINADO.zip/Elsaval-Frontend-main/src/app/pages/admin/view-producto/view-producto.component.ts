import { Component, OnInit } from '@angular/core';
import { ElementoService } from 'src/app/services/elemento.service';
import { MovimientoService } from 'src/app/services/movimiento.service';
import Swal from 'sweetalert2';
import { combineLatest } from 'rxjs';
import { AlmacenService } from 'src/app/services/almacen.service';

@Component({
  selector: 'app-view-producto',
  templateUrl: './view-producto.component.html',
  styleUrls: ['./view-producto.component.css']
})
export class ViewProductoComponent implements OnInit {
  elementos: any = [];
  movimientos: any = [];
  almacenes: any[] = [];
  currentPage1 = 1;
  rowsPerPage1 = 10;
  totalPages1 = 0;
  currentPage2 = 1;
  rowsPerPage2 = 10;
  totalPages2 = 0;
  selectedAlmacen: any = '';
  searchTerm1: string = ''; // Nueva propiedad para el término de búsqueda
  almacenList: string[] = ["Materiales", "Implementos", "Equipos"];

  constructor(
    private elementoService: ElementoService,
    private movimientoService: MovimientoService,
    private almacenService: AlmacenService
  ) {}

  prevPage1(): void {
    if (this.currentPage1 > 1) {
      this.currentPage1--;
    }
  }

  nextPage1(): void {
    if (this.currentPage1 < this.totalPages1) {
      this.currentPage1++;
    }
  }

  prevPage2(): void {
    if (this.currentPage2 > 1) {
      this.currentPage2--;
    }
  }

  nextPage2(): void {
    if (this.currentPage2 < this.totalPages2) {
      this.currentPage2++;
    }
  }

  calculateTotalPages1(): void {
    this.totalPages1 = Math.ceil(this.filteredElementos().length / this.rowsPerPage1);
    if (this.currentPage1 > this.totalPages1) {
      this.currentPage1 = 1;
    }
  }

  calculateTotalPages2(): void {
    this.totalPages2 = Math.ceil(this.movimientos.length / this.rowsPerPage2);
    if (this.currentPage2 > this.totalPages2) {
      this.currentPage2 = 1;
    }
  }

  displayedProductos(): any[] {
    const startIndex = (this.currentPage1 - 1) * this.rowsPerPage1;
    const endIndex = startIndex + this.rowsPerPage1;
    return this.filteredElementos().slice(startIndex, endIndex);
  }

  displayedMovimientos(): any[] {
    const startIndex = (this.currentPage2 - 1) * this.rowsPerPage2;
    const endIndex = startIndex + this.rowsPerPage2;
    return this.filteredMovimientos().slice(startIndex, endIndex);
  }
  
  filteredMovimientos(): any[] {
    const filtered = this.movimientos.filter((movimiento: any) => {
      const nombreProductoCoincide = movimiento.producto.producto.toLowerCase().startsWith(this.searchTerm1.toLowerCase());
      const almacenCoincide = !this.selectedAlmacen || this.selectedAlmacen === movimiento.almacen.titulo;
  
      console.log('Nombre del producto coincide:', nombreProductoCoincide);
      console.log('Almacen coincide:', almacenCoincide);
  
      return nombreProductoCoincide && almacenCoincide;
    });
  
    console.log('Movimientos filtrados:', filtered);
  
    return filtered;
  }

  filteredElementos(): any[] {
    const filtered = this.elementos.filter((elemento: any) => {
      const nombreCoincide = elemento.producto.toLowerCase().startsWith(this.searchTerm1.toLowerCase());
      const almacenCoincide = !this.selectedAlmacen || this.selectedAlmacen === elemento.almacen.titulo;
  
      console.log('Nombre coincide:', nombreCoincide);
      console.log('Almacen coincide:', almacenCoincide);
  
      return nombreCoincide && almacenCoincide;
    });
  
    console.log('Elementos filtrados:', filtered);
  
    return filtered;
  }
  eliminarProducto(elemento_id: any): void {
    {
      Swal.fire({
        title: 'Eliminar producto',
        text: '¿Estás seguro de eliminar la información de la lista?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Eliminar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          this.elementoService.eliminarElemento(elemento_id).subscribe(
            (data) => {
              this.elementos = this.elementos.filter((elemento: any) => elemento.elemento_id != elemento_id);
              Swal.fire('Producto eliminado', 'El producto ha sido eliminado de la base de datos', 'success');
              this.calculateTotalPages1();
            },
            (error) => {
              console.error('Error al eliminar el producto:', error);
              if (error.status === 401) {
                Swal.fire('No autorizado', 'Usuario no autorizado para realizar esta acción', 'error');
              } else {
                Swal.fire('No se puede eliminar', 'El producto tiene movimientos registrados', 'warning');
              }
            }
          );
        }
      });
    }
  }
  ngOnInit(): void {
    combineLatest([
      this.elementoService.listarElementos(),
      this.movimientoService.listarMovimientos(),
      this.almacenService.listarAlmacenes()
    ]).subscribe(
      ([elementos, movimientos, almacenes]: [any, any, any]) => {
        this.elementos = elementos;
        this.movimientos = movimientos;
        this.almacenes = almacenes;

        console.log('Productos:', this.displayedProductos());
        console.log('Movimientos:', this.displayedMovimientos());
        console.log('Elementos cargados:', this.elementos);
        console.log('Almacenes cargados:', this.almacenes);
  
        this.calculateTotalPages1();
        this.calculateTotalPages2();
      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar los datos', 'error');
      }
    );
  }
}