import { Component, OnInit } from '@angular/core';
import { CasaService } from 'src/app/services/casa.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-casa',
  templateUrl: './view-casa.component.html',
  styleUrls: ['./view-casa.component.css']
})
export class ViewCasaComponent implements OnInit {
  casas: any = [

  ]
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;
  constructor(private casasService: CasaService) { }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
  calculateTotalPages():void{
    this.totalPages = Math.ceil(this.casas.length / this.rowsPerPage);
    if(this.currentPage > this.totalPages){
      this.currentPage = 1;
    }
  }
  displayedCasas():any[]{
    const starIndex = (this.currentPage -1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.casas.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.casasService.listarCasas().subscribe(
      (dato:any) => {
        this.casas = dato;
        this.calculateTotalPages();
        console.log(this.casas);
        
      },
      (error) =>{
        console.log(error);
        Swal.fire('Error','Error al cargar llas casas','error');
      }
    )  
  }
  eliminarCasa(casaId:any){
    Swal.fire({
      title:'Eliminar Casa',
      text:'¿Estas seguro de eliminar la informacion de la Casa?',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.casasService.eliminarCasa(casaId).subscribe(
          (data)=>{
            this.casas = this.casas.filter((casa:any)=> casa.casaId != casaId);
            Swal.fire('Casa eliminado','La casa ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar el socio de la base de datos','error');
          }
        )
      }
    })
  }
}
