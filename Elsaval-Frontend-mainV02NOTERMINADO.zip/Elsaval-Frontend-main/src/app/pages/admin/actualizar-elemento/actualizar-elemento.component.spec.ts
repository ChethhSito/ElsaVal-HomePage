import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarElementoComponent } from './actualizar-elemento.component';

describe('ActualizarElementoComponent', () => {
  let component: ActualizarElementoComponent;
  let fixture: ComponentFixture<ActualizarElementoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ActualizarElementoComponent]
    });
    fixture = TestBed.createComponent(ActualizarElementoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
