import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AlmacenService } from 'src/app/services/almacen.service';
import { ElementoService } from 'src/app/services/elemento.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-elemento',
  templateUrl: './actualizar-elemento.component.html',
  styleUrls: ['./actualizar-elemento.component.css']
})
export class ActualizarElementoComponent implements OnInit{

  constructor(
    private route:ActivatedRoute, 
    private elementoService:ElementoService,
    private AlmacemSevice:AlmacenService,
    private router:Router){}

  elmentoId = 0;
  elemento:any;
  almacenes:any;

  ngOnInit():void{
    this.elmentoId = this.route.snapshot.params['elementoId'];
    this.elementoService.obtenerElemento(this.elmentoId).subscribe(
      (data) => {
        this.elemento = data;
        console.log(this.elemento)
      },
      (error)=> {
        console.log(error);
      }
    )

    this.AlmacemSevice.listarAlmacenes().subscribe(
      (data:any) =>{
        this.almacenes = data;
      },
      (error)=>{
        alert('Error al cargar los almacenes')
      }
    )
    
  }
  public actualizarDatos(){
    this.elementoService.actualizarElemento(this.elemento).subscribe(
      (data) => {
          Swal.fire('Elemento actualizado','El elemento ha sido actualizado con exito', 'success').then(
            (e)=> {
              this.router.navigate(['/admin/elementos']);
            }
          );
      },
      (error) =>{
        Swal.fire('Error en el sistema','No se ha podido actualizar el elemento', 'error');
        console.log(error);
      }
    )
  }
}
