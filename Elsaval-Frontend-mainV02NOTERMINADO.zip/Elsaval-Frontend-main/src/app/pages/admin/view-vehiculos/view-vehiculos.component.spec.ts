import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewVehiculosComponent } from './view-vehiculos.component';

describe('ViewVehiculosComponent', () => {
  let component: ViewVehiculosComponent;
  let fixture: ComponentFixture<ViewVehiculosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewVehiculosComponent]
    });
    fixture = TestBed.createComponent(ViewVehiculosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
