import { Component, OnInit } from '@angular/core';
import { VehiculosService } from 'src/app/services/vehiculos.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-view-vehiculos',
  templateUrl: './view-vehiculos.component.html',
  styleUrls: ['./view-vehiculos.component.css']
})
export class ViewVehiculosComponent implements OnInit{
  vehiculos: any = [

  ]
  currentPage = 1;
  rowsPerPage = 10;
  totalPages = 0;

  constructor(private vehiculoService: VehiculosService) { }

  prevPage(): void {
    if (this.currentPage > 1) {
      this.currentPage--;
    }
  }

  nextPage(): void {
    if (this.currentPage < this.totalPages) {
      this.currentPage++;
    }
  }
  calculateTotalPages(): void {
    this.totalPages = Math.ceil(this.vehiculos.length / this.rowsPerPage);
    if (this.currentPage > this.totalPages) {
      this.currentPage = 1;
    }
  }
  displayedLanchas(): any[] {
    const starIndex = (this.currentPage - 1) * this.rowsPerPage;
    const endIndex = starIndex + this.rowsPerPage;
    return this.vehiculos.slice(starIndex, endIndex);
  }
  ngOnInit(): void {
    this.vehiculoService.listarVehiculos().subscribe(
      (dato: any) => {
        this.vehiculos = dato;
        this.calculateTotalPages();
        console.log(this.vehiculos);

      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar los vehiculos', 'error');
      }
    )
  }
  eliminarVehiculo(vehiculoId:any){
    Swal.fire({
      title:'Eliminar lancha',
      text:'¿Estas seguro de eliminar lancha seleccionado',
      icon:'warning',
      showCancelButton: true,
      confirmButtonColor:'#3085d6',
      cancelButtonColor:'#d33',
      confirmButtonText:'Eliminar',
      cancelButtonText:'Cancelar'
    }).then((result)=>{
      if(result.isConfirmed){
        this.vehiculoService.eliminarVehiculo(vehiculoId).subscribe(
          (data)=>{
            this.vehiculos = this.vehiculos.filter((vehiculo:any)=> vehiculo.vehiculoId != vehiculoId);
            Swal.fire('Elemento eliminado','El vehiculo ha sido eliminado de la base de datos','success');

          },
          (error)=>{
            Swal.fire('Error','Error al eliminar vehiculo de la base de datos','error');
          }
        )
      }
    })
  }
}
