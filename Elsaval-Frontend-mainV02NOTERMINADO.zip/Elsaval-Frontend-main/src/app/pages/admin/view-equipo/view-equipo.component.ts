import { Component, OnInit } from '@angular/core';
import { EquipoService } from 'src/app/services/equipo.service';
import { EquipoMovimientoService} from 'src/app/services/equipomovimiento.service';
import Swal from 'sweetalert2';
import { combineLatest } from 'rxjs';


@Component({
  selector: 'app-view-equipo',
  templateUrl: './view-equipo.component.html',
  styleUrls: ['./view-equipo.component.css']
})
export class ViewEquipoComponent implements OnInit {
  equipos: any = [];
  movimientos: any = [];
  currentPage1 = 1;
  rowsPerPage1 = 10;
  totalPages1 = 0;
  currentPage2 = 1;
  rowsPerPage2 = 10;
  totalPages2 = 0;
  searchTerm1: string = '';

  constructor(
    private equipoService: EquipoService,
    private equipomovimientoService: EquipoMovimientoService,
  ) {}

  prevPage1(): void {
    if (this.currentPage1 > 1) {
      this.currentPage1--;
    }
  }

  nextPage1(): void {
    if (this.currentPage1 < this.totalPages1) {
      this.currentPage1++;
    }
  }

  prevPage2(): void {
    if (this.currentPage2 > 1) {
      this.currentPage2--;
    }
  }

  nextPage2(): void {
    if (this.currentPage2 < this.totalPages2) {
      this.currentPage2++;
    }
  }

  calculateTotalPages1(): void {
    this.totalPages1 = Math.ceil(this.filteredElementos().length / this.rowsPerPage1);
    if (this.currentPage1 > this.totalPages1) {
      this.currentPage1 = 1;
    }
  }

  calculateTotalPages2(): void {
    this.totalPages2 = Math.ceil(this.movimientos.length / this.rowsPerPage2);
    if (this.currentPage2 > this.totalPages2) {
      this.currentPage2 = 1;
    }
  }

  displayedProductos(): any[] {
    const startIndex = (this.currentPage1 - 1) * this.rowsPerPage1;
    const endIndex = startIndex + this.rowsPerPage1;
    return this.filteredElementos().slice(startIndex, endIndex);
  }

  displayedMovimientos(): any[] {
    const startIndex = (this.currentPage2 - 1) * this.rowsPerPage2;
    const endIndex = startIndex + this.rowsPerPage2;
    return this.filteredMovimientos().slice(startIndex, endIndex);
  }
  
  filteredMovimientos(): any[] {
    const filtered = this.movimientos.filter((movimiento: any) => {
      const nombreProductoCoincide = movimiento.equipo.producto.toLowerCase().startsWith(this.searchTerm1.toLowerCase());
  
      console.log('Nombre del producto coincide:', nombreProductoCoincide);
  
      return nombreProductoCoincide;
    });
  
    console.log('Movimientos filtrados:', filtered);
  
    return filtered;
  }

  filteredElementos(): any[] {
    const filtered = this.equipos.filter((equipo: any) => {
      const nombreCoincide = equipo.producto.toLowerCase().startsWith(this.searchTerm1.toLowerCase());
  
      console.log('Nombre coincide:', nombreCoincide);
  
      return nombreCoincide
    });
  
    console.log('Elementos filtrados:', filtered);
  
    return filtered;
  }
  eliminarProducto(equipoId: any): void {
    {
      Swal.fire({
        title: 'Eliminar producto',
        text: '¿Estás seguro de eliminar la información de la lista?',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Eliminar',
        cancelButtonText: 'Cancelar'
      }).then((result) => {
        if (result.isConfirmed) {
          this.equipoService.eliminarEquipo(equipoId).subscribe(
            (data) => {
              this.equipos = this.equipos.filter((equipo: any) => equipo.equipoId != equipoId);
              Swal.fire('Producto eliminado', 'El producto ha sido eliminado de la base de datos', 'success');
              this.calculateTotalPages1();
            },
            (error) => {
              console.error('Error al eliminar el producto:', error);
              if (error.status === 401) {
                Swal.fire('No autorizado', 'Usuario no autorizado para realizar esta acción', 'error');
              } else {
                Swal.fire('No se puede eliminar', 'El producto tiene movimientos registrados', 'warning');
              }
            }
          );
        }
      });
    }
  }
  ngOnInit(): void {
    combineLatest([
      this.equipoService.listarEquipos(),
      this.equipomovimientoService.listarMovimientos(),
    ]).subscribe(
      ([equipos, movimientos]: [any, any]) => {
        this.equipos = equipos;
        this.movimientos = movimientos;

        console.log('Productos:', this.displayedProductos());
        console.log('Movimientos:', this.displayedMovimientos());
        console.log('Equipos cargados:', this.equipos);
  
        this.calculateTotalPages1();
        this.calculateTotalPages2();
      },
      (error) => {
        console.log(error);
        Swal.fire('Error', 'Error al cargar los datos', 'error');
      }
    );
  }
}