import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddEspejosComponent } from './add-espejos.component';

describe('AddEspejosComponent', () => {
  let component: AddEspejosComponent;
  let fixture: ComponentFixture<AddEspejosComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddEspejosComponent]
    });
    fixture = TestBed.createComponent(AddEspejosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
