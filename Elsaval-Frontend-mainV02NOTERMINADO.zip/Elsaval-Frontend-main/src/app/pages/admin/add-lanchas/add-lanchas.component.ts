import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { LanchaService } from 'src/app/services/lancha.service';
import { SocioService } from 'src/app/services/socio.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-add-lanchas',
  templateUrl: './add-lanchas.component.html',
  styleUrls: ['./add-lanchas.component.css']
})
export class AddLanchasComponent implements OnInit {
  estados = ['Disponible', 'No Disponible', 'En mantenimiento', 'Averiada', 'En Uso'];

  socios: any = [];

  lanchasData = {
    nombrelancha: '',
    modelo: '',
    hin: '',
    marca: '',
    activo: true,
    estado: '',
    color: '',
    socio: {
      socioId: ''
    }
  }

  constructor(private socioService: SocioService,
    private snack: MatSnackBar,
    private lanchaService: LanchaService,
    private router: Router) { }

  ngOnInit(): void {
    this.socioService.listarSocios().subscribe(
      (dato: any) => {
        this.socios = dato;
        console.log(this.socios);
      }, (error) => {
        console.log(error);
        Swal.fire('Error !!', 'Error al cargar los datos', 'error')
      }
    )
  }
  guardarInformacion() {
    console.log(this.lanchasData);
    if (this.lanchasData.hin.trim() == '' || this.lanchasData.hin == null) {
      this.snack.open('El numero del HIN es requerido', '', {
        duration: 4000
      });
      return;
    }
    this.lanchaService.agregarLancha(this.lanchasData).subscribe(
      (data) => {
        Swal.fire('Lancha Guardado', 'La lancha ha sido guardado con exito', 'success');
        this.lanchasData = {
          nombrelancha: '',
          modelo: '',
          hin: '',
          marca: '',
          activo: true,
          estado: '',
          color: '',
          socio: {
            socioId: ''
          }
        }
        this.router.navigate(['/admin/lanchas'])
      },
      (error) => {
        Swal.fire('Error', 'Error al guardar la lancha en el sistema','error');
      }
    )
  }
}
