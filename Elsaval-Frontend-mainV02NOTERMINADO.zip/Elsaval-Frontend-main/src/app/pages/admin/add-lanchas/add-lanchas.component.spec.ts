import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddLanchasComponent } from './add-lanchas.component';

describe('AddLanchasComponent', () => {
  let component: AddLanchasComponent;
  let fixture: ComponentFixture<AddLanchasComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AddLanchasComponent]
    });
    fixture = TestBed.createComponent(AddLanchasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
